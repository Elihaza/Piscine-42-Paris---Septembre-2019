#include <stdio.h>

int main(int ac, char **argv)
{
	if (ac == 3)
	{
		printf("atoi base : %d\n", ft_atoi_base(av[1], atoi(av[2])));
	}
	return (0);
}
